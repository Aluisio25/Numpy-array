import numpy as np

def calculate(list):
    matrix_aux = np.matrix([list[0:3],list[3:6],list[6:9]])
    
    print(matrix_aux)

    std_flattened = np.std(matrix_aux)
    var_flattened = np.var(matrix_aux)
    mean_flattened = np.mean(matrix_aux)
    max_flattened = np.max(matrix_aux)
    min_flattened = np.min(matrix_aux)
    sum_flattened = np.sum(matrix_aux)


    #matrix_aux[0]
    std_axis1 = np.std(matrix_aux[:,0])
    std_axis2 = np.std(matrix_aux[0,:])
    var_axis1 = np.var(matrix_aux[:,0])
    var_axis2 = np.var(matrix_aux[0,:])
    mean_axis1 = np.mean(matrix_aux[:,0])
    mean_axis2 = np.mean(matrix_aux[0,:])
    max_axis1 = np.max(matrix_aux[:,0])
    max_axis2 = np.max(matrix_aux[0,:])
    min_axis1 = np.min(matrix_aux[:,0])
    min_axis2 = np.min(matrix_aux[0,:])
    sum_axis1 = np.sum(matrix_aux[:,0])
    sum_axis2 = np.sum(matrix_aux[0,:])
  
    calculations =  {
    'mean': [mean_axis1, mean_axis2, mean_flattened],
    'variance': [var_axis1, var_axis2, var_flattened],
    'standard deviation': [std_axis1, std_axis2, std_flattened],
    'max': [max_axis1, max_axis2, max_flattened],
    'min': [min_axis1, min_axis2, min_flattened],
    'sum': [min_axis1, min_axis2, min_flattened]
    }  
    return calculations 

print (calculate([0,1,2,3,4,5,6,7,8]))